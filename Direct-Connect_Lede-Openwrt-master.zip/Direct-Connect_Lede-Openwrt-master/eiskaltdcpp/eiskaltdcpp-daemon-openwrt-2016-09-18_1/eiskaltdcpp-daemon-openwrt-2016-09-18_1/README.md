[![Build Status](https://travis-ci.org/makefu/eiskaltdcpp-daemon-openwrt.svg?branch=master)](https://travis-ci.org/makefu/eiskaltdcpp-daemon-openwrt)

eiskaltdcpp-daemon-openwrt
==========================
