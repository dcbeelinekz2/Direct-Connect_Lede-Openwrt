[![Build Status](https://travis-ci.org/kraiz/eiskaltdcpp-daemon-openwrt.svg?branch=master)](https://travis-ci.org/kraiz/eiskaltdcpp-daemon-openwrt)

eiskaltdcpp-daemon-openwrt
==========================
